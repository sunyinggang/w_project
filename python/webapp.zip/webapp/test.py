#encoding = utf-8
"""
 Created by Felix on 
"""
__author__ = 'Felix'

str = 'a,b,c'

arr = str.split(',')

for v in arr:
    print(v)

