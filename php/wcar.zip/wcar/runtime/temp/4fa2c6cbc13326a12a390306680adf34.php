<?php if (!defined('THINK_PATH')) exit(); /*a:4:{s:80:"D:\phpStudy\WWW\wcar\public/../application/admin\view\index\change_password.html";i:1581750843;s:62:"D:\phpStudy\WWW\wcar\application\admin\view\public\header.html";i:1582542311;s:60:"D:\phpStudy\WWW\wcar\application\admin\view\public\menu.html";i:1582546365;s:62:"D:\phpStudy\WWW\wcar\application\admin\view\public\footer.html";i:1580726882;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>车辆审核管理系统</title>

    <!-- Bootstrap core CSS -->
    <link href="/wcar/public/static/index/css/bootstrap.css" rel="stylesheet">

    <!-- Add custom CSS here -->
    <link href="/wcar/public/static/index/css/sb-admin.css" rel="stylesheet">
    <link href="/wcar/public/static/index/font-awesome/css/font-awesome.css" rel="stylesheet">
    <link href="/wcar/public/static/index/css/style.css" rel="stylesheet">
    <!-- Page Specific CSS -->
    <link rel="stylesheet" href="/wcar/public/static/index/css/morris-0.4.3.min.css">
    <link href="/wcar/public/static/index/css/bootstrap-datetimepicker.css" rel="stylesheet" media="screen">
    <link rel="stylesheet" href="/wcar/public/static/index/css/fileinput.css">
</head>

<body>

<div id="wrapper">

    <!-- Sidebar -->
    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
        <a class="navbar-brand" href="<?php echo url('index/index'); ?>">车辆管理系统</a>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse navbar-ex1-collapse">
        <ul class="nav navbar-nav side-nav left-sidenav left-sidenav-menu">
            <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-desktop"></i>  <span>信息审核</span> <span class="menu-arrow"><i class="glyphicon glyphicon-chevron-right"></i></span></a>
                <ul class="dropdown-menu">
                    <li><a href="<?php echo url('index/reviewList',['key'=>6]); ?>">行驶证基本信息</a></li>
                    <li><a href="<?php echo url('index/reviewList',['key'=>7]); ?>">行驶证副业基本信息</a></li>
                    <li><a href="<?php echo url('index/reviewList',['key'=>2]); ?>">驾驶证基本信息</a></li>
                    <li><a href="<?php echo url('index/reviewList',['key'=>3]); ?>">驾驶员副页基本信息</a></li>
                    <li><a href="<?php echo url('index/reviewList',['key'=>4]); ?>">身份证基本信息（正页）</a></li>
                    <li><a href="<?php echo url('index/reviewList',['key'=>5]); ?>">身份证基本信息(副页)</a></li>
                    <li><a href="<?php echo url('index/reviewList',['key'=>0]); ?>">车辆页</a></li>
                    <li><a href="<?php echo url('index/reviewList',['key'=>1]); ?>">车辆外观</a></li>
                </ul>
            </li>
            <li><a href="<?php echo url('index/processStatus',['status'=>1]); ?>"><i class="glyphicon glyphicon-eye-open"></i>已受理审核列表</a></li>
            <li><a href="<?php echo url('index/processStatus',['status'=>0]); ?>"><i class="glyphicon glyphicon-eye-close"></i>未受理审核列表</a></li>
            <li><a href="<?php echo url('index/processStatus',['status'=>2]); ?>"><i class="glyphicon glyphicon-exclamation-sign"></i>错误信息列表</a></li>
            <li><a href="<?php echo url('index/processToday'); ?>"><i class="glyphicon glyphicon-ok-circle"></i>今日审核信息列表</a></li>
            <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="glyphicon glyphicon-user"></i>  车主信息统计<span class="menu-arrow"><i class="glyphicon glyphicon-chevron-right"></i></span></a>
                <ul class="dropdown-menu">
                  <li><a href="<?php echo url('index/userInfo',['type'=>1]); ?>">车主年龄统计</a></li>
                  <li><a href="<?php echo url('index/userInfo',['type'=>2]); ?>">车主车龄统计</a></li>
                </ul>
            </li>
        </ul>

        <ul class="nav navbar-nav navbar-right navbar-user">
            <li class="dropdown user-dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-user"></i> <?php echo $user["name"]; ?><b class="caret"></b></a>
                <ul class="dropdown-menu">
                    <li><a href="<?php echo url('index/changePassword'); ?>"><i class="fa fa-gear"></i> 修改密码</a></li>
                    <li><a href="<?php echo url('index/login/logout',['role'=>1]); ?>"><i class="fa fa-power-off"></i>退出</a></li>
                </ul>
            </li>
        </ul>
    </div><!-- /.navbar-collapse -->
</nav>

    <div id="page-wrapper">
        <div class="row">
            <div class="col-lg-4"></div>
            <div class="col-lg-4">
                    <div class="form-group">
                        <form method="post" action="<?php echo url('index/changePassword'); ?>" role="form">
                        <h1>修改密码</h1>
                            <div class="form-group">
                                <label>输入新密码</label>
                                <input type="password" name="password">
                            </div>
                            <div class="form-group">
                                <label>再次输入新密码</label>
                                <input type="password" name="passwordt">
                            </div>
                        <button style="margin-top: 20px;" type="submit" class="btn btn-primary">确认修改</button>
                        </form>
                    </div>

                </form>
            </div>
            <div class="col-lg-4"></div>
        </div><!-- /.row -->

    </div><!-- /#page-wrapper -->

</div><!-- /#wrapper -->

<!-- JavaScript -->
<script src="/wcar/public/static/index/js/jquery.min.js"></script>
<!--<script src="/wcar/public/static/index/js/jquery-1.10.2.js"></script>-->
<script src="/wcar/public/static/index/js/bootstrap.js"></script>

<script src="/wcar/public/static/index/js/raphael-min.js"></script>
<script src="/wcar/public/static/index/js/morris-0.4.3.min.js"></script>
<script src="/wcar/public/static/index/js/tablesorter/jquery.tablesorter.js"></script>
<script src="/wcar/public/static/index/js/tablesorter/tables.js"></script>
<script src="/wcar/public/static/index/js/fileinput.js"></script>
<script src="/wcar/public/static/index/js/fileinput_locale_zh.js"></script>
<script src="/wcar/public/static/index/js/bootstrap-datetimepicker.js" type="text/javascript" charset="UTF-8"></script>
</body>
</html>