<?php if (!defined('THINK_PATH')) exit(); /*a:4:{s:73:"D:\phpStudy\WWW\wcar\public/../application/admin\view\index\car_show.html";i:1581669395;s:62:"D:\phpStudy\WWW\wcar\application\admin\view\public\header.html";i:1580726743;s:60:"D:\phpStudy\WWW\wcar\application\admin\view\public\menu.html";i:1581670482;s:62:"D:\phpStudy\WWW\wcar\application\admin\view\public\footer.html";i:1580726882;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>车辆审核管理系统</title>

    <!-- Bootstrap core CSS -->
    <link href="/wcar/public/static/index/css/bootstrap.css" rel="stylesheet">

    <!-- Add custom CSS here -->
    <link href="/wcar/public/static/index/css/sb-admin.css" rel="stylesheet">
    <!-- Page Specific CSS -->
    <link rel="stylesheet" href="/wcar/public/static/index/css/morris-0.4.3.min.css">
    <link href="/wcar/public/static/index/css/bootstrap-datetimepicker.css" rel="stylesheet" media="screen">
    <link rel="stylesheet" href="/wcar/public/static/index/css/fileinput.css">
</head>

  <body>

    <div id="wrapper">

      <!-- Sidebar -->
      <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
        <a class="navbar-brand" href="index.html">车辆管理系统</a>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse navbar-ex1-collapse">
        <ul class="nav navbar-nav side-nav">
            <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-desktop"></i>  信息审核 <b class="caret"></b></a>
                <ul class="dropdown-menu">
                    <li><a href="<?php echo url('index/reviewList',['key'=>6]); ?>">行驶证基本信息</a></li>
                    <li><a href="<?php echo url('index/reviewList',['key'=>7]); ?>">行驶证副业基本信息</a></li>
                    <li><a href="<?php echo url('index/reviewList',['key'=>2]); ?>">驾驶证基本信息</a></li>
                    <li><a href="<?php echo url('index/reviewList',['key'=>3]); ?>">驾驶员副页基本信息</a></li>
                    <li><a href="<?php echo url('index/reviewList',['key'=>4]); ?>">身份证基本信息（正页）</a></li>
                    <li><a href="<?php echo url('index/reviewList',['key'=>5]); ?>">身份证基本信息(副页)</a></li>
                    <li><a href="<?php echo url('index/reviewList',['key'=>0]); ?>">车辆页</a></li>
                    <li><a href="<?php echo url('index/reviewList',['key'=>1]); ?>">车辆外观</a></li>
                </ul>
            </li>
            <li><a href="<?php echo url('index/processStatus',['status'=>1]); ?>">已受理审核列表</a></li>
            <li><a href="<?php echo url('index/processStatus',['status'=>0]); ?>">未受理审核列表</a></li>
            <li><a href="<?php echo url('index/processStatus',['status'=>2]); ?>">错误信息列表</a></li>
            <li><a href="tables.html">信息统计</a></li>
        </ul>

        <ul class="nav navbar-nav navbar-right navbar-user">
            <li class="dropdown user-dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-user"></i> <?php echo $user["name"]; ?><b class="caret"></b></a>
                <ul class="dropdown-menu">
                    <li><a href="#"><i class="fa fa-gear"></i> 管理员信息</a></li>
                    <li><a href="#"><i class="fa fa-gear"></i> 修改密码</a></li>
                    <li><a href="#"><i class="fa fa-power-off"></i>退出</a></li>
                </ul>
            </li>
        </ul>
    </div><!-- /.navbar-collapse -->
</nav>

      <div id="page-wrapper">
        <div class="row">
          <div class="col-lg-4"></div>
          <div class="col-lg-4">
            <form method="post" action="<?php echo url('index/carShow'); ?>" role="form">
              <h1>车辆外观</h1>
              <input type="hidden" value="车辆外观" name="title">
              <div class="form-group">
                <label>插入车辆图片</label>
                <input type="file" id="input-id" name="img" accept="image/*"/>
              </div>
              <?php if($res['status'] == 0): ?>
              <a class="btn btn-primary" href="<?php echo url('index/carShow',['id'=>$res['id'],'status'=>1,'key'=>1]); ?>" role="button">审核通过</a>
              <a class="btn btn-danger" href="<?php echo url('index/suggest',['id'=>$res['id'],'key'=>1]); ?>" role="button">审核不通过</a>
              <?php elseif($res['status'] == 2): ?>
              <label>修改建议</label>
              <textarea name="suggest" style="height: 100px;" class="form-control"><?php echo $res['suggest']; ?></textarea>
              <?php else: endif; ?>
              <input type="hidden" value="" name="picture_url" id="path">
            </form>
          </div>
          <div class="col-lg-4"></div>
        </div><!-- /.row -->

      </div><!-- /#page-wrapper -->

    </div><!-- /#wrapper -->

    <!-- JavaScript -->
<script src="/wcar/public/static/index/js/jquery.min.js"></script>
<!--<script src="/wcar/public/static/index/js/jquery-1.10.2.js"></script>-->
<script src="/wcar/public/static/index/js/bootstrap.js"></script>

<script src="/wcar/public/static/index/js/raphael-min.js"></script>
<script src="/wcar/public/static/index/js/morris-0.4.3.min.js"></script>
<script src="/wcar/public/static/index/js/tablesorter/jquery.tablesorter.js"></script>
<script src="/wcar/public/static/index/js/tablesorter/tables.js"></script>
<script src="/wcar/public/static/index/js/fileinput.js"></script>
<script src="/wcar/public/static/index/js/fileinput_locale_zh.js"></script>
<script src="/wcar/public/static/index/js/bootstrap-datetimepicker.js" type="text/javascript" charset="UTF-8"></script>
    <script>
        $(document).ready(function(){
            $("#path").attr("value","<?php echo $res['picture_url']; ?>");
        });
        $("#input-id").fileinput({
            language: "zh",
            showCaption: false, // 不显示本地文件名
            allowedFileTypes: ['image'], // 只允许上传图片
            allowedFileExtensions: ["jpg", "jpeg", "png", "gif"],
            initialPreview: [
                '<img class="file-preview-image kv-preview-data" src='+'"<?php echo $res['picture_url']; ?>">'
            ],
            uploadUrl: "<?php echo url('index/upload'); ?>" //上传图片的服务器地址
        }).on("fileuploaded", function (event, data, previewId, index){
            $("#path").attr("value",data.response["path"]);
        });
    </script>
  </body>
</html>