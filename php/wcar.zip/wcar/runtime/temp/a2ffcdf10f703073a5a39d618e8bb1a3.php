<?php if (!defined('THINK_PATH')) exit(); /*a:4:{s:70:"D:\phpStudy\WWW\wcar\public/../application/admin\view\index\index.html";i:1584979115;s:62:"D:\phpStudy\WWW\wcar\application\admin\view\public\header.html";i:1582542311;s:60:"D:\phpStudy\WWW\wcar\application\admin\view\public\menu.html";i:1582608838;s:62:"D:\phpStudy\WWW\wcar\application\admin\view\public\footer.html";i:1582607500;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>车辆审核管理系统</title>

    <!-- Bootstrap core CSS -->
    <link href="/wcar/public/static/index/css/bootstrap.css" rel="stylesheet">

    <!-- Add custom CSS here -->
    <link href="/wcar/public/static/index/css/sb-admin.css" rel="stylesheet">
    <link href="/wcar/public/static/index/font-awesome/css/font-awesome.css" rel="stylesheet">
    <link href="/wcar/public/static/index/css/style.css" rel="stylesheet">
    <!-- Page Specific CSS -->
    <link rel="stylesheet" href="/wcar/public/static/index/css/morris-0.4.3.min.css">
    <link href="/wcar/public/static/index/css/bootstrap-datetimepicker.css" rel="stylesheet" media="screen">
    <link rel="stylesheet" href="/wcar/public/static/index/css/fileinput.css">
</head>

  <body>
    <div id="wrapper">

      <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
        <a class="navbar-brand" href="<?php echo url('index/index'); ?>">车辆管理系统</a>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse navbar-ex1-collapse">
        <ul class="nav navbar-nav side-nav left-sidenav left-sidenav-menu">
            <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-desktop"></i>  <span>信息审核</span> <span class="menu-arrow"><i class="glyphicon glyphicon-chevron-right"></i></span></a>
                <ul class="dropdown-menu">
                    <li><a href="<?php echo url('index/reviewList',['key'=>6]); ?>">行驶证基本信息</a></li>
                    <li><a href="<?php echo url('index/reviewList',['key'=>7]); ?>">行驶证副业基本信息</a></li>
                    <li><a href="<?php echo url('index/reviewList',['key'=>2]); ?>">驾驶证基本信息</a></li>
                    <li><a href="<?php echo url('index/reviewList',['key'=>3]); ?>">驾驶员副页基本信息</a></li>
                    <li><a href="<?php echo url('index/reviewList',['key'=>4]); ?>">身份证基本信息（正页）</a></li>
                    <li><a href="<?php echo url('index/reviewList',['key'=>5]); ?>">身份证基本信息(副页)</a></li>
                    <li><a href="<?php echo url('index/reviewList',['key'=>0]); ?>">车辆页</a></li>
                    <li><a href="<?php echo url('index/reviewList',['key'=>1]); ?>">车辆外观</a></li>
                </ul>
            </li>
            <li><a href="<?php echo url('index/processStatus',['status'=>1]); ?>"><i class="glyphicon glyphicon-eye-open"></i>已受理审核列表</a></li>
            <li><a href="<?php echo url('index/processStatus',['status'=>0]); ?>"><i class="glyphicon glyphicon-eye-close"></i>未受理审核列表</a></li>
            <li><a href="<?php echo url('index/processStatus',['status'=>2]); ?>"><i class="glyphicon glyphicon-exclamation-sign"></i>错误信息列表</a></li>
            <li><a href="<?php echo url('index/processToday'); ?>"><i class="glyphicon glyphicon-ok-circle"></i>今日审核信息列表</a></li>
            <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="glyphicon glyphicon-user"></i>  车主信息统计<span class="menu-arrow"><i class="glyphicon glyphicon-chevron-right"></i></span></a>
                <ul class="dropdown-menu">
                  <li><a href="<?php echo url('index/userInfo',['type'=>1]); ?>">车主年龄统计</a></li>
                  <li><a href="<?php echo url('index/userInfo',['type'=>2]); ?>">车主车龄统计</a></li>
                </ul>
            </li>
        </ul>

        <ul class="nav navbar-nav navbar-right navbar-user">
            <li class="dropdown user-dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-user"></i> 欢迎您，<?php echo $user["name"]; ?><b class="caret"></b></a>
                <ul class="dropdown-menu">
                    <li><a href="<?php echo url('index/changePassword'); ?>"><i class="fa fa-gear"></i> 修改密码</a></li>
                    <li><a href="<?php echo url('index/login/logout',['role'=>1]); ?>"><i class="fa fa-power-off"></i>退出</a></li>
                </ul>
            </li>
        </ul>
    </div><!-- /.navbar-collapse -->
</nav>
      <div class="page-content">
        <div class="container-fluid ">
          <div class="row"><div class="col-sm-12"><h1>欢迎进入车辆管理系统</h1></div></div>
          <div class="row" style="margin-top: 40px;">
            <div class="col-lg-3">
                <div class="card card-content">
                  <div class="card-body row justify-content-center"><div class="col-lg-5 align-self-center"><h4 class="mt-0 mb-2 font-20"><?php echo $count1; ?></h4><p class="mb-2 text-muted font-13 text-nowrap">已受理</p><span class="badge badge-soft-success mt-1 shadow-none"></span></div><div class="col-lg-7 align-self-center"><span class="peity-line" data-width="100%" data-peity="{ &quot;fill&quot;: [&quot;#b5f1e0&quot;],&quot;stroke&quot;: [&quot;#0acf97&quot;]}" data-height="80" style="display: none;">1,2,3,4,3,6,3,5,3,3,4,2</span><svg class="peity" height="80" width="100%"><polygon fill="#b5f1e0" points="0 79.5 0 66.33333333333333 9.456000000000001 53.16666666666667 18.912000000000003 40 28.368000000000002 26.833333333333336 37.824000000000005 40 47.28000000000001 0.5 56.736000000000004 40 66.19200000000001 13.666666666666657 75.64800000000001 40 85.10400000000001 40 94.56000000000002 26.833333333333336 104.01600000000002 53.16666666666667 104.016 79.5"></polygon><polyline fill="none" points="0 66.33333333333333 9.456000000000001 53.16666666666667 18.912000000000003 40 28.368000000000002 26.833333333333336 37.824000000000005 40 47.28000000000001 0.5 56.736000000000004 40 66.19200000000001 13.666666666666657 75.64800000000001 40 85.10400000000001 40 94.56000000000002 26.833333333333336 104.01600000000002 53.16666666666667" stroke="#0acf97" stroke-width="1" stroke-linecap="square"></polyline></svg></div></div>
                  <a href="<?php echo url('index/processStatus',['status'=>1]); ?>">
                    <div class="panel-footer announcement-bottom">
                      <div class="row">
                        <div class="col-xs-6">
                          查看
                        </div>
                        <div class="col-xs-6 text-right">
                          <i class="fa fa-arrow-circle-right"></i>
                        </div>
                      </div>
                    </div>
                  </a>
                </div>
              </div>
            <div class="col-lg-3">
              <div class="card card-content">
                <div class="card-body row justify-content-center"><div class="col-lg-5 align-self-center"><h4 class="mt-0 mb-2 font-20"><?php echo $count0; ?></h4><p class="mb-2 text-muted font-13 text-nowrap">未受理</p><span class="badge badge-soft-success mt-1 shadow-none"></span></div><div class="col-lg-7 align-self-center text-right"><span class="peity-line" data-width="100%" data-peity="{ &quot;fill&quot;: [&quot;#d6d8f5&quot;],&quot;stroke&quot;: [&quot;#777edd&quot;]}" data-height="80" style="display: none;">0,3,6,3,4,2,6,1,8,4,4,2</span><svg class="peity" height="80" width="100%"><polygon fill="#d6d8f5" points="0 79.5 0 79.5 9.456000000000001 49.875 18.912000000000003 20.25 28.368000000000002 49.875 37.824000000000005 40 47.28000000000001 59.75 56.736000000000004 20.25 66.19200000000001 69.625 75.64800000000001 0.5 85.10400000000001 40 94.56000000000002 40 104.01600000000002 59.75 104.016 79.5"></polygon><polyline fill="none" points="0 79.5 9.456000000000001 49.875 18.912000000000003 20.25 28.368000000000002 49.875 37.824000000000005 40 47.28000000000001 59.75 56.736000000000004 20.25 66.19200000000001 69.625 75.64800000000001 0.5 85.10400000000001 40 94.56000000000002 40 104.01600000000002 59.75" stroke="#777edd" stroke-width="1" stroke-linecap="square"></polyline></svg></div></div>
                <a href="<?php echo url('index/processStatus',['status'=>0]); ?>">
                  <div class="panel-footer announcement-bottom">
                    <div class="row">
                      <div class="col-xs-6">
                        查看
                      </div>
                      <div class="col-xs-6 text-right">
                        <i class="fa fa-arrow-circle-right"></i>
                      </div>
                    </div>
                  </div>
                </a>
              </div>
            </div>
            <div class="col-lg-3">
              <div class="card card-content">
                <div class="card-body row justify-content-center"><div class="col-lg-5 align-self-center"><h4 class="mt-0 mb-2 font-20"><?php echo $count2; ?></h4><p class="mb-2 text-muted font-13 text-nowrap">未通过</p><span class="badge badge-soft-success mt-1 shadow-none"></span></div><div class="col-lg-7 align-self-center"><span class="peity-line" data-width="100%" data-peity="{ &quot;fill&quot;: [&quot;#fdebb5&quot;],&quot;stroke&quot;: [&quot;#f9bc0b&quot;]}" data-height="80" style="display: none;">2,4,7,3,5,3,6,3,4,3,2,1,2</span><svg class="peity" height="80" width="100%"><polygon fill="#fdebb5" points="0 79.5 0 56.92857142857143 8.668000000000001 34.35714285714286 17.336000000000002 0.5 26.004000000000005 45.642857142857146 34.672000000000004 23.07142857142857 43.34 45.642857142857146 52.00800000000001 11.785714285714292 60.67600000000001 45.642857142857146 69.34400000000001 34.35714285714286 78.01200000000001 45.642857142857146 86.68 56.92857142857143 95.34800000000001 68.21428571428572 104.01600000000002 56.92857142857143 104.016 79.5"></polygon><polyline fill="none" points="0 56.92857142857143 8.668000000000001 34.35714285714286 17.336000000000002 0.5 26.004000000000005 45.642857142857146 34.672000000000004 23.07142857142857 43.34 45.642857142857146 52.00800000000001 11.785714285714292 60.67600000000001 45.642857142857146 69.34400000000001 34.35714285714286 78.01200000000001 45.642857142857146 86.68 56.92857142857143 95.34800000000001 68.21428571428572 104.01600000000002 56.92857142857143" stroke="#f9bc0b" stroke-width="1" stroke-linecap="square"></polyline></svg></div></div>
                <a href="<?php echo url('index/processStatus',['status'=>2]); ?>">
                  <div class="panel-footer announcement-bottom">
                    <div class="row">
                      <div class="col-xs-6">
                        查看
                      </div>
                      <div class="col-xs-6 text-right">
                        <i class="fa fa-arrow-circle-right"></i>
                      </div>
                    </div>
                  </div>
                </a>
              </div>
            </div>
            <div class="col-lg-3">
              <div class="card card-content">
                <div class="card-body row justify-content-center"><div class="col-lg-5 align-self-center"><h4 class="mt-0 mb-2 font-20"><?php echo $countToday; ?></h4><p class="mb-2 text-muted font-13 text-nowrap">今日审核</p><span class="badge badge-soft-success mt-1 shadow-none"></span></div><div class="col-lg-7 align-self-center"><span class="peity-bar" data-peity="{ &quot;fill&quot;: [&quot;#ffd1e1&quot;, &quot;#ffd1e1&quot;]}" data-width="100%" data-height="80" style="display: none;">5,6,2,8,9,4,7,10,11,12,10,4,7,10</span><svg class="peity" height="80" width="100%"><rect data-value="5" fill="#ffd1e1" x="0.7429714285714287" y="46.666666666666664" width="5.943771428571429" height="33.333333333333336"></rect><rect data-value="6" fill="#ffd1e1" x="8.172685714285716" y="40" width="5.943771428571427" height="40"></rect><rect data-value="2" fill="#ffd1e1" x="15.602400000000001" y="66.66666666666667" width="5.943771428571429" height="13.333333333333329"></rect><rect data-value="8" fill="#ffd1e1" x="23.03211428571429" y="26.66666666666667" width="5.943771428571424" height="53.33333333333333"></rect><rect data-value="9" fill="#ffd1e1" x="30.461828571428573" y="20" width="5.943771428571434" height="60"></rect><rect data-value="4" fill="#ffd1e1" x="37.89154285714285" y="53.333333333333336" width="5.943771428571438" height="26.666666666666664"></rect><rect data-value="7" fill="#ffd1e1" x="45.32125714285714" y="33.33333333333333" width="5.943771428571431" height="46.66666666666667"></rect><rect data-value="10" fill="#ffd1e1" x="52.750971428571425" y="13.333333333333329" width="5.943771428571438" height="66.66666666666667"></rect><rect data-value="11" fill="#ffd1e1" x="60.18068571428571" y="6.666666666666671" width="5.943771428571445" height="73.33333333333333"></rect><rect data-value="12" fill="#ffd1e1" x="67.6104" y="0" width="5.943771428571438" height="80"></rect><rect data-value="10" fill="#ffd1e1" x="75.04011428571428" y="13.333333333333329" width="5.943771428571438" height="66.66666666666667"></rect><rect data-value="4" fill="#ffd1e1" x="82.46982857142858" y="53.333333333333336" width="5.943771428571424" height="26.666666666666664"></rect><rect data-value="7" fill="#ffd1e1" x="89.89954285714285" y="33.33333333333333" width="5.943771428571452" height="46.66666666666667"></rect><rect data-value="10" fill="#ffd1e1" x="97.32925714285714" y="13.333333333333329" width="5.943771428571424" height="66.66666666666667"></rect></svg></div></div>
                <a href="<?php echo url('index/processToday'); ?>">
                  <div class="panel-footer announcement-bottom">
                    <div class="row">
                      <div class="col-xs-6">
                        查看
                      </div>
                      <div class="col-xs-6 text-right">
                        <i class="fa fa-arrow-circle-right"></i>
                      </div>
                    </div>
                  </div>
                </a>
              </div>
            </div>
          </div>
        </div>
     </div><!-- /.row -->

      </div><!-- /#wrapper -->
    <footer class="footer text-sm-left">© 2019-2020 <span class="text-muted d-none d-sm-inline-block float-right">Crafted with <i class="mdi mdi-heart text-danger"></i>by <a href="#">文承华</a></span></footer>
<!-- JavaScript -->
<script src="/wcar/public/static/index/js/jquery.min.js"></script>
<!--<script src="/wcar/public/static/index/js/jquery-1.10.2.js"></script>-->
<script src="/wcar/public/static/index/js/bootstrap.js"></script>

<script src="/wcar/public/static/index/js/raphael-min.js"></script>
<script src="/wcar/public/static/index/js/morris-0.4.3.min.js"></script>
<script src="/wcar/public/static/index/js/tablesorter/jquery.tablesorter.js"></script>
<script src="/wcar/public/static/index/js/tablesorter/tables.js"></script>
<script src="/wcar/public/static/index/js/fileinput.js"></script>
<script src="/wcar/public/static/index/js/fileinput_locale_zh.js"></script>
<script src="/wcar/public/static/index/js/bootstrap-datetimepicker.js" type="text/javascript" charset="UTF-8"></script>
  </body>
</html>
