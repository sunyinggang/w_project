<?php if (!defined('THINK_PATH')) exit(); /*a:4:{s:76:"D:\phpStudy\WWW\wcar\public/../application/admin\view\index\review_list.html";i:1581668039;s:62:"D:\phpStudy\WWW\wcar\application\admin\view\public\header.html";i:1580726743;s:60:"D:\phpStudy\WWW\wcar\application\admin\view\public\menu.html";i:1581670116;s:62:"D:\phpStudy\WWW\wcar\application\admin\view\public\footer.html";i:1580726882;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>车辆审核管理系统</title>

    <!-- Bootstrap core CSS -->
    <link href="/wcar/public/static/index/css/bootstrap.css" rel="stylesheet">

    <!-- Add custom CSS here -->
    <link href="/wcar/public/static/index/css/sb-admin.css" rel="stylesheet">
    <!-- Page Specific CSS -->
    <link rel="stylesheet" href="/wcar/public/static/index/css/morris-0.4.3.min.css">
    <link href="/wcar/public/static/index/css/bootstrap-datetimepicker.css" rel="stylesheet" media="screen">
    <link rel="stylesheet" href="/wcar/public/static/index/css/fileinput.css">
</head>

  <body>

    <div id="wrapper">

      <!-- Sidebar -->
      <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
        <a class="navbar-brand" href="index.html">车辆管理系统</a>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse navbar-ex1-collapse">
        <ul class="nav navbar-nav side-nav">
            <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-desktop"></i>  信息审核 <b class="caret"></b></a>
                <ul class="dropdown-menu">
                    <li><a href="<?php echo url('index/reviewList',['key'=>6]); ?>">行驶证基本信息</a></li>
                    <li><a href="<?php echo url('index/reviewList',['key'=>7]); ?>">行驶证副业基本信息</a></li>
                    <li><a href="<?php echo url('index/reviewList',['key'=>2]); ?>">驾驶证基本信息</a></li>
                    <li><a href="<?php echo url('index/reviewList',['key'=>3]); ?>">驾驶员副页基本信息</a></li>
                    <li><a href="<?php echo url('index/reviewList',['key'=>4]); ?>">身份证基本信息（正页）</a></li>
                    <li><a href="<?php echo url('index/reviewList',['key'=>5]); ?>">身份证基本信息(副页)</a></li>
                    <li><a href="<?php echo url('index/reviewList',['key'=>0]); ?>">车辆页</a></li>
                    <li><a href="<?php echo url('index/reviewList',['key'=>1]); ?>">车辆外观</a></li>
                </ul>
            </li>
            <li><a href="<?php echo url('index/processStatus',['status'=>1]); ?>">已受理审核列表</a></li>
            <li><a href="tables.html">未受理审核列表</a></li>
            <li><a href="tables.html">错误信息列表</a></li>
            <li><a href="tables.html">信息统计</a></li>
        </ul>

        <ul class="nav navbar-nav navbar-right navbar-user">
            <li class="dropdown user-dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-user"></i> <?php echo $user["name"]; ?><b class="caret"></b></a>
                <ul class="dropdown-menu">
                    <li><a href="#"><i class="fa fa-gear"></i> 管理员信息</a></li>
                    <li><a href="#"><i class="fa fa-gear"></i> 修改密码</a></li>
                    <li><a href="#"><i class="fa fa-power-off"></i>退出</a></li>
                </ul>
            </li>
        </ul>
    </div><!-- /.navbar-collapse -->
</nav>

      <div id="page-wrapper">

        <div class="row">
          <div class="col-lg-12">
            <h1><?php echo $title; ?>审核列表</h1>
          </div>
        </div><!-- /.row -->

        <div class="row">
          <div class="col-lg-12">
            <div class="table-responsive">
              <table class="table table-bordered table-hover tablesorter">
                <thead>
                  <tr>
                    <th>名称<i class="fa fa-sort"></i></th>
                    <th>提交日期<i class="fa fa-sort"></i></th>
                    <th>修改日期<i class="fa fa-sort"></i></th>
                    <th>审核状态<i class="fa fa-sort"></i></th>
                    <th>操作<i class="fa fa-sort"></i></th>
                  </tr>
                </thead>
                <tbody>
                <?php if(is_array($res) || $res instanceof \think\Collection || $res instanceof \think\Paginator): $i = 0; $__LIST__ = $res;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$data): $mod = ($i % 2 );++$i;?>
                  <tr>
                    <td><?php echo $data["title"]; ?></td>
                    <td><?php echo $data["create_time"]; ?></td>
                    <td><?php echo $data["update_time"]; ?>0</td>
                    <?php if($data['status'] == 0): ?>
                    <td><span class="label label-default">待审核</span></td>
                    <?php elseif($data['status'] == 1): ?>
                    <td><span class="label label-success">审核通过</span></td>
                    <?php else: ?>
                    <td><span class="label label-danger">未修改</span></td>
                    <?php endif; ?>
                    <td><a class="btn btn-primary" href="<?php echo url('index/middleWare',['key'=>$keyT,'id'=>$data['id']]); ?>" role="button">查看</a></td>
                  </tr>
                <?php endforeach; endif; else: echo "" ;endif; ?>
                </tbody>
              </table>
            </div>
          </div>
        </div><!-- /.row -->

      </div><!-- /#page-wrapper -->

    </div><!-- /#wrapper -->

    <!-- JavaScript -->
<script src="/wcar/public/static/index/js/jquery.min.js"></script>
<!--<script src="/wcar/public/static/index/js/jquery-1.10.2.js"></script>-->
<script src="/wcar/public/static/index/js/bootstrap.js"></script>

<script src="/wcar/public/static/index/js/raphael-min.js"></script>
<script src="/wcar/public/static/index/js/morris-0.4.3.min.js"></script>
<script src="/wcar/public/static/index/js/tablesorter/jquery.tablesorter.js"></script>
<script src="/wcar/public/static/index/js/tablesorter/tables.js"></script>
<script src="/wcar/public/static/index/js/fileinput.js"></script>
<script src="/wcar/public/static/index/js/fileinput_locale_zh.js"></script>
<script src="/wcar/public/static/index/js/bootstrap-datetimepicker.js" type="text/javascript" charset="UTF-8"></script>

  </body>
</html>