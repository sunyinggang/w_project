<?php if (!defined('THINK_PATH')) exit(); /*a:4:{s:67:"D:\phpStudy\WWW\wcar\public/../application/user\view\index\car.html";i:1583490894;s:61:"D:\phpStudy\WWW\wcar\application\user\view\public\header.html";i:1582609047;s:59:"D:\phpStudy\WWW\wcar\application\user\view\public\menu.html";i:1582609936;s:61:"D:\phpStudy\WWW\wcar\application\user\view\public\footer.html";i:1582607997;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>车辆审核管理系统</title>

    <!-- Bootstrap core CSS -->
    <link href="/wcar/public/static/index/css/bootstrap.css" rel="stylesheet">

    <!-- Add custom CSS here -->
    <link href="/wcar/public/static/index/css/sb-admin.css" rel="stylesheet">
    <link href="/wcar/public/static/index/css/style.css" rel="stylesheet">
    <link href="/wcar/public/static/index/font-awesome/css/font-awesome.css" rel="stylesheet">
    <!-- Page Specific CSS -->
    <link rel="stylesheet" href="/wcar/public/static/index/css/morris-0.4.3.min.css">
    <link href="/wcar/public/static/index/css/bootstrap-datetimepicker.css" rel="stylesheet" media="screen">
    <link rel="stylesheet" href="/wcar/public/static/index/css/fileinput.css">
</head>

  <body>

    <div id="wrapper">

      <!-- Sidebar -->
      <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
        <a class="navbar-brand" href="<?php echo url('index/index'); ?>">车辆审核管理系统</a>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse navbar-ex1-collapse">
        <ul class="nav navbar-nav side-nav left-sidenav left-sidenav-menu">
            <li><a href="<?php echo url('index/carerInfo'); ?>"><i class="glyphicon glyphicon-user"></i>  我的信息</a></li>
            <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="glyphicon glyphicon-file"></i>  行驶证信息审核 <span class="menu-arrow"><i class="glyphicon glyphicon-chevron-right"></i></span></a>
                <ul class="dropdown-menu">
                    <li><a href="<?php echo url('index/travelCard'); ?>">行驶证基本信息</a></li>
                    <li><a href="<?php echo url('index/travelSubpage'); ?>">行驶证副业基本信息</a></li>
                </ul>
            </li>
            <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="glyphicon glyphicon-list-alt"></i>  驾驶证信息审核 <span class="menu-arrow"><i class="glyphicon glyphicon-chevron-right"></i></span></a>
                <ul class="dropdown-menu">
                    <li><a href="<?php echo url('index/driveCard'); ?>">驾驶证基本信息</a></li>
                    <li><a href="<?php echo url('index/driveSubpage'); ?>">驾驶证副页基本信息</a></li>
                </ul>
            </li>
            <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="glyphicon glyphicon-credit-card"></i>  身份证信息审核 <span class="menu-arrow"><i class="glyphicon glyphicon-chevron-right"></i></span></a>
                <ul class="dropdown-menu">
                    <li><a href="<?php echo url('index/idCard'); ?>">身份证基本信息（正页）</a></li>
                    <li><a href="<?php echo url('index/idSubpage'); ?>">身份证基本信息(副页)</a></li>
                </ul>
            </li>
            <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="glyphicon glyphicon-road"></i>  车辆信息审核 <span class="menu-arrow"><i class="glyphicon glyphicon-chevron-right"></i></span></a>
                <ul class="dropdown-menu">
                    <li><a href="<?php echo url('index/car'); ?>">车辆页</a></li>
                    <li><a href="<?php echo url('index/carShow'); ?>">车辆外观</a></li>
                </ul>
            </li>
            <li><a href="<?php echo url('index/reviewProgress'); ?>"><i class="glyphicon glyphicon-time"></i>信息审核进度</a></li>
        </ul>

        <ul class="nav navbar-nav navbar-right navbar-user">
            <li class="dropdown user-dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-user"></i> 欢迎您，<?php echo $user["name"]; ?><b class="caret"></b></a>
                <ul class="dropdown-menu">
                    <li><a href="<?php echo url('index/user'); ?>"><i class="fa fa-gear"></i> 审核人信息</a></li>
                    <li><a href="<?php echo url('index/changePassword'); ?>"><i class="fa fa-gear"></i> 修改密码</a></li>
                    <li><a href="<?php echo url('index/login/logout',['role'=>0]); ?>"><i class="fa fa-power-off"></i>退出</a></li>
                </ul>
            </li>
        </ul>
    </div><!-- /.navbar-collapse -->
</nav>

      <div id="page-wrapper">
        <div class="row">
          <div class="col-lg-4"></div>
          <div class="col-lg-4">
            <form method="post" action="<?php echo url('index/car'); ?>" role="form">
              <h1>车辆页</h1>
              <input type="hidden" value="车辆页" name="title">
              <div class="form-group">
                <label>插入车辆图片</label>
                <input type="file" id="input-id" name="img" accept="image/*">
              </div>
              <?php if($res == null): ?>
              <button type="submit" class="btn btn-primary">确认添加</button>
              <?php else: ?>
              <button type="submit" class="btn btn-primary">确认修改</button>
              <?php endif; ?>
              <input type="hidden" value="" name="picture_url" id="path">
            </form>
          </div>
          <div class="col-lg-4"></div>
        </div><!-- /.row -->

      </div><!-- /#page-wrapper -->

    </div><!-- /#wrapper -->

    <footer class="footer text-sm-left">© 2019-2020 <span class="text-muted d-none d-sm-inline-block float-right">Crafted with <i class="mdi mdi-heart text-danger"></i>by <a href="#">文承华</a></span></footer>
<!-- JavaScript -->
<script src="/wcar/public/static/index/js/jquery.min.js"></script>
<!--<script src="/wcar/public/static/index/js/jquery-1.10.2.js"></script>-->
<script src="/wcar/public/static/index/js/bootstrap.js"></script>

<script src="/wcar/public/static/index/js/raphael-min.js"></script>
<script src="/wcar/public/static/index/js/morris-0.4.3.min.js"></script>
<script src="/wcar/public/static/index/js/tablesorter/jquery.tablesorter.js"></script>
<script src="/wcar/public/static/index/js/tablesorter/tables.js"></script>
<script src="/wcar/public/static/index/js/fileinput.js"></script>
<script src="/wcar/public/static/index/js/fileinput_locale_zh.js"></script>
<script src="/wcar/public/static/index/js/bootstrap-datetimepicker.js" type="text/javascript" charset="UTF-8"></script>
    <script>
        $(document).ready(function(){
            $("#path").attr("value","<?php echo $res['picture_url']; ?>");
        });
        $("#input-id").fileinput({
            language: "zh",
            showCaption: false, // 不显示本地文件名
            allowedFileTypes: ['image'], // 只允许上传图片
            allowedFileExtensions: ["jpg", "jpeg", "png", "gif"],
            initialPreview: [
                '<img class="file-preview-image kv-preview-data" src='+'"<?php echo $res['picture_url']; ?>">'
            ],
            uploadUrl: "<?php echo url('index/upload'); ?>" //上传图片的服务器地址
        }).on("fileuploaded", function (event, data, previewId, index){
            $("#path").attr("value",data.response["path"]);
        });
    </script>
  </body>
</html>