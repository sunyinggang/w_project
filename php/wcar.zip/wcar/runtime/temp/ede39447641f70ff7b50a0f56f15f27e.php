<?php if (!defined('THINK_PATH')) exit(); /*a:4:{s:75:"D:\phpStudy\WWW\wcar\public/../application/user\view\index\travel_card.html";i:1580727696;s:61:"D:\phpStudy\WWW\wcar\application\user\view\public\header.html";i:1580726743;s:59:"D:\phpStudy\WWW\wcar\application\user\view\public\menu.html";i:1580716648;s:61:"D:\phpStudy\WWW\wcar\application\user\view\public\footer.html";i:1580726882;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>车辆审核管理系统</title>

    <!-- Bootstrap core CSS -->
    <link href="/wcar/public/static/index/css/bootstrap.css" rel="stylesheet">

    <!-- Add custom CSS here -->
    <link href="/wcar/public/static/index/css/sb-admin.css" rel="stylesheet">
    <!-- Page Specific CSS -->
    <link rel="stylesheet" href="/wcar/public/static/index/css/morris-0.4.3.min.css">
    <link href="/wcar/public/static/index/css/bootstrap-datetimepicker.css" rel="stylesheet" media="screen">
    <link rel="stylesheet" href="/wcar/public/static/index/css/fileinput.css">
</head>

  <body>

    <div id="wrapper">

      <!-- Sidebar -->
      <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
        <a class="navbar-brand" href="<?php echo url('index/index'); ?>">车辆审核管理系统</a>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse navbar-ex1-collapse">
        <ul class="nav navbar-nav side-nav">
            <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-desktop"></i>  信息审核 <b class="caret"></b></a>
                <ul class="dropdown-menu">
                    <li><a href="<?php echo url('index/carerInfo'); ?>">车主基本信息</a></li>
                    <li><a href="<?php echo url('index/travelCard'); ?>">行驶证基本信息</a></li>
                    <li><a href="<?php echo url('index/travelSubpage'); ?>">行驶证副业基本信息</a></li>
                    <li><a href="<?php echo url('index/driveCard'); ?>">驾驶证基本信息</a></li>
                    <li><a href="<?php echo url('index/driveSubpage'); ?>">驾驶证副页基本信息</a></li>
                    <li><a href="<?php echo url('index/idCard'); ?>">身份证基本信息（正页）</a></li>
                    <li><a href="<?php echo url('index/idSubpage'); ?>">身份证基本信息(副页)</a></li>
                    <li><a href="<?php echo url('index/car'); ?>">车辆页</a></li>
                    <li><a href="<?php echo url('index/carShow'); ?>">车辆外观</a></li>
                </ul>
            </li>
            <li><a href="<?php echo url('index/reviewProgress'); ?>">信息审核进度</a></li>
        </ul>

        <ul class="nav navbar-nav navbar-right navbar-user">
            <li class="dropdown user-dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-user"></i> <?php echo $user["name"]; ?><b class="caret"></b></a>
                <ul class="dropdown-menu">
                    <li><a href="<?php echo url('index/user'); ?>"><i class="fa fa-gear"></i> 审核人信息</a></li>
                    <li><a href="#"><i class="fa fa-gear"></i> 修改密码</a></li>
                    <li><a href="<?php echo url('index/login/logout'); ?>"><i class="fa fa-power-off"></i>退出</a></li>
                </ul>
            </li>
        </ul>
    </div><!-- /.navbar-collapse -->
</nav>

      <div id="page-wrapper">
        <div class="row">
          <div class="col-lg-4"></div>
          <div class="col-lg-4">
            <form method="post" action="<?php echo url('index/travelCard'); ?>" role="form">
              <h1>行驶证基本信息</h1>
              <input type="hidden" value="行驶证基本信息" name="title">
              <div class="form-group">
                <label>车辆号码</label>
                <input type="text" class="form-control" placeholder="" value="<?php echo $res['number']; ?>" name="number">
              </div>
              <div class="form-group">
                <label>车辆类型</label>
                <input type="text" class="form-control" placeholder="" value="<?php echo $res['car_type']; ?>" name="car_type">
              </div>
              <div class="form-group">
                <label>所有人</label>
                <input type="text" class="form-control" placeholder="" value="<?php echo $res['car_user']; ?>" name="car_user">
              </div>
              <div class="form-group">
                <label>地址</label>
                <input type="text" class="form-control" placeholder="" value="<?php echo $res['address']; ?>" name="address">
              </div>
              <div class="form-group">
                <label>使用性质</label>
                <input type="text" class="form-control" placeholder="" value="<?php echo $res['user_nature']; ?>" name="user_nature">
              </div>
              <div class="form-group">
                <label>品牌型号</label>
                <input type="text" class="form-control" placeholder="" value="<?php echo $res['logo']; ?>" name="logo">
              </div>
              <div class="form-group">
                <label>车辆识别代码</label>
                <input type="text" class="form-control" placeholder="" value="<?php echo $res['identify_code']; ?>" name="identify_code">
              </div>
              <div class="form-group">
                <label>发动机号码</label>
                <input type="text" class="form-control" placeholder="" value="<?php echo $res['engine_num']; ?>" name="engine_num">
              </div>
              <div class="form-group">
                <label>注册日期</label>
                <input type="text" class="form-control" placeholder="如：2020-02-22" value="<?php echo $res['register_date']; ?>" name="register_date">
              </div>
              <div class="form-group">
                <label>发证日期</label>
                <input type="text" class="form-control" placeholder="如：2020-02-22" value="<?php echo $res['send_date']; ?>" name="send_date">
              </div>
              <div class="form-group">
                <label>插入行驶证图片</label>
                <input type="file" id="input-id" value="" name="img" accept="image/*"/>
              </div>
              <?php if($res == null): ?>
              <button type="submit" class="btn btn-primary">确认添加</button>
              <?php else: ?>
              <button type="submit" class="btn btn-primary">确认修改</button>
              <?php endif; ?>
              <input type="hidden" value="" name="picture_url" id="path">
            </form>
          </div>
          <div class="col-lg-4"></div>
        </div><!-- /.row -->

      </div><!-- /#page-wrapper -->

    </div><!-- /#wrapper -->

    <!-- JavaScript -->
<script src="/wcar/public/static/index/js/jquery.min.js"></script>
<!--<script src="/wcar/public/static/index/js/jquery-1.10.2.js"></script>-->
<script src="/wcar/public/static/index/js/bootstrap.js"></script>

<script src="/wcar/public/static/index/js/raphael-min.js"></script>
<script src="/wcar/public/static/index/js/morris-0.4.3.min.js"></script>
<script src="/wcar/public/static/index/js/tablesorter/jquery.tablesorter.js"></script>
<script src="/wcar/public/static/index/js/tablesorter/tables.js"></script>
<script src="/wcar/public/static/index/js/fileinput.js"></script>
<script src="/wcar/public/static/index/js/fileinput_locale_zh.js"></script>
<script src="/wcar/public/static/index/js/bootstrap-datetimepicker.js" type="text/javascript" charset="UTF-8"></script>

    <script>
        $(document).ready(function(){
            $("#path").attr("value","<?php echo $res['picture_url']; ?>");
        });
        $("#input-id").fileinput({
            language: "zh",
            showCaption: false, // 不显示本地文件名
            allowedFileTypes: ['image'], // 只允许上传图片
            allowedFileExtensions: ["jpg", "jpeg", "png", "gif"],
            initialPreview: [
                '<img class="file-preview-image kv-preview-data" src='+'"<?php echo $res['picture_url']; ?>">'
            ],
            uploadUrl: "<?php echo url('index/upload'); ?>" //上传图片的服务器地址
        }).on("fileuploaded", function (event, data, previewId, index){
            $("#path").attr("value",data.response["path"]);
        });


    </script>
  </body>
</html>