<?php


namespace app\common\model;


class TravelCard extends BaseModel
{

}