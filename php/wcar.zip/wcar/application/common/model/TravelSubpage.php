<?php


namespace app\common\model;


class TravelSubpage extends BaseModel
{

}