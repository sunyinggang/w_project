<?php


namespace app\common\model;


class DriveSubpage extends BaseModel
{

}