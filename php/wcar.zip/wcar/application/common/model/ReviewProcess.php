<?php


namespace app\common\model;


class ReviewProcess extends BaseModel
{

}