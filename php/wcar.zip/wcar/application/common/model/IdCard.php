<?php


namespace app\common\model;


class IdCard extends BaseModel
{

}