<?php


namespace app\common\model;


class IdSubpage extends BaseModel
{

}