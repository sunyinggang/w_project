<?php
namespace app\common\model;


class Car extends BaseModel
{

}