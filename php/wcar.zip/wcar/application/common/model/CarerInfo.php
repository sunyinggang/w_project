<?php


namespace app\common\model;


class CarerInfo extends BaseModel
{

}