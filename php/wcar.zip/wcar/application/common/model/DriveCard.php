<?php


namespace app\common\model;


class DriveCard extends BaseModel
{

}