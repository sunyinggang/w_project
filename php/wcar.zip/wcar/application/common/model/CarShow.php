<?php


namespace app\common\model;


class CarShow extends BaseModel
{

}