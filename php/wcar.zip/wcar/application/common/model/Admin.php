<?php


namespace app\common\model;


class Admin extends BaseModel
{

}