<?php


namespace app\common\model;


class Spite extends BaseModel
{

}