<?php


namespace app\common\model;


class Infringement extends BaseModel
{

}