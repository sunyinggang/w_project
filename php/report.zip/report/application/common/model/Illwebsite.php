<?php


namespace app\common\model;


class Illwebsite extends BaseModel
{

}