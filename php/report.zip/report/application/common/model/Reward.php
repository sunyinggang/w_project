<?php


namespace app\common\model;


class Reward extends BaseModel
{

}