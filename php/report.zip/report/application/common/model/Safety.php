<?php


namespace app\common\model;


class Safety extends BaseModel
{

}