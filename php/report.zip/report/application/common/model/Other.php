<?php


namespace app\common\model;


class Other extends BaseModel
{

}