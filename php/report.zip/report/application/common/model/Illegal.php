<?php


namespace app\common\model;


class Illegal extends BaseModel
{

}