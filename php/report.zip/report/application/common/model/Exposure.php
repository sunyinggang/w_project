<?php


namespace app\common\model;


class Exposure extends BaseModel
{

}