<?php


namespace app\common\model;


class Leakage extends BaseModel
{

}