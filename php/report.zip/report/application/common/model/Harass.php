<?php


namespace app\common\model;


class Harass extends BaseModel
{

}