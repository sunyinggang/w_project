<?php


namespace app\common\model;


class Clue extends BaseModel
{

}