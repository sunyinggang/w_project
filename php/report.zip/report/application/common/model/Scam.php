<?php


namespace app\common\model;


class Scam extends BaseModel
{

}