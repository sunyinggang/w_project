<?php


namespace app\common\model;


class Rumor extends BaseModel
{

}