<?php


namespace app\common\model;


class User extends BaseModel
{

}